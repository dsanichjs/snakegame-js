var canvas = document.getElementById('game')
var context = canvas.getContext('2d')
var grid = 20;
var speed = 0;

var snake = {
  x: 160,
  y: 160,

  dx: grid,
  dy: 0,

  cells: [],
  startLength: 1
}

var eat = {
  x: 320,
  y: 320
}

let scoreSnake = 0;
let nowSpeed = -10;

function generator(min, max) {
  return Math.floor(Math.random()*(max - min)) + min;
}

function loop() {
  requestAnimationFrame(loop);
  if (++speed < 4) {
    return;
  }

  // if(scoreSnake == 0) {
  //   // speed = -10;
  //   nowSpeed = -10;
  // } else {
  //   if(scoreSnake % 5 == 0) {
  //     // speed++;
  //     nowSpeed++;
  //   }
  // }

  speed = nowSpeed;


  // console.log('speed', speed);
  // console.log('nowSpeed', nowSpeed);

  context.clearRect(0,0, canvas.width, canvas.height);

  snake.x += snake.dx;
  snake.y += snake.dy;

  if (snake.x === canvas.width || snake.y === canvas.height || snake.x < 0 || snake.y < 0) {
    alert("Вы проиграли! Ваш счет равен: " + scoreSnake + ". " + "Для новой игры нажмите F5")
  }


  snake.cells.unshift({x: snake.x, y: snake.y})
  if (snake.cells.length > snake.startLength) {
    snake.cells.pop();
  }
  var img = new Image();
  img.src = 'img/shkura.jpg';

  const imgEat = new Image();
  imgEat.src = 'img/eat1.png';
  context.drawImage(imgEat, eat.x, eat.y, 20, 20);
  // context.fillRect(eat.x, eat.y, grid - 1,  grid - 1);
  const pattern = context.createPattern(img, 'repeat');
  context.fillStyle = pattern;
  snake.cells.forEach(function(cell, index) {
    context.fillRect(cell.x, cell.y, grid - 1,  grid - 1);


    if(cell.x == eat.x && cell.y == eat.y) {
      snake.startLength++;
      scoreSnake = snake.startLength - 1;

      eat.x = generator(0, 30) * grid;
      eat.y = generator(0, 30) * grid;
      console.log(scoreSnake);
      document.getElementById("score12").innerHTML = scoreSnake;
      if(scoreSnake!==0 && scoreSnake % 10 == 0) {
        console.log(scoreSnake, nowSpeed);
        nowSpeed += 1;
      }
    }


    for(let i = index + 1; i < snake.cells.length; i++) {
      if(cell.x === snake.cells[i].x && cell.y === snake.cells[i].y) {
        alert("Вы проиграли! Ваш счет равен: " + scoreSnake + ". " + "Для новой игры нажмите F5")
      }
    }
  })
document.addEventListener('keydown', function(e){
  if (e.which === 37 && snake.dx === 0) {
    snake.dx = -grid;
    snake.dy = 0;
  }
  else if (e.which === 38 && snake.dy === 0){
    snake.dy = -grid;
    snake.dx = 0;
  }
  else if (e.which === 39 && snake.dx === 0){
    snake.dx = grid;
    snake.dy = 0;
  }
  else if (e.which === 40 && snake.dy === 0){
    snake.dy = grid;
    snake.dx = 0;
  }
})

}
requestAnimationFrame(loop);
